float euler(float xinitial, float xfinal, long int nsteps, float yinitial)
{
  float x, y, dx;
  int i;

  dx = (xfinal-xinitial)/nsteps;
  x = xinitial;
  y = yinitial;

  for (i=0; i<nsteps; i++) {
    y = y + dx*func(x,y);
    x = x + dx;
  }
  return y;
}
